import React from 'react'
import "./Footer.css"
function Footer() {
    return (
        <footer >
            <h2 className="rms">TIP CALCULATOR USING REACT</h2>
        </footer>
    )
}

export default Footer