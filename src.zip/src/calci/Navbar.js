import React from 'react'
import "./Navbar.css"
function Navbar() {
  return (
  
      <nav>
      TIP CALCULATOR
      </nav>
  )
}

export default Navbar
